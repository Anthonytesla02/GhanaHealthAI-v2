import { chatMessages, documentChunks, type ChatMessage, type DocumentChunk, users, type User, type InsertUser } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getChatMessages(sessionId: string): Promise<ChatMessage[]>;
  addChatMessage(message: any): Promise<ChatMessage>;
  getDocumentChunks(): Promise<DocumentChunk[]>;
  addDocumentChunk(chunk: any): Promise<DocumentChunk>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private chatMessages: Map<string, ChatMessage[]>;
  private documentChunks: DocumentChunk[];
  private currentUserId: number;
  private currentMessageId: number;
  private currentChunkId: number;

  constructor() {
    this.users = new Map();
    this.chatMessages = new Map();
    this.documentChunks = [];
    this.currentUserId = 1;
    this.currentMessageId = 1;
    this.currentChunkId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getChatMessages(sessionId: string): Promise<ChatMessage[]> {
    return this.chatMessages.get(sessionId) || [];
  }

  async addChatMessage(message: any): Promise<ChatMessage> {
    const id = this.currentMessageId++;
    const chatMessage: ChatMessage = {
      id,
      sessionId: message.sessionId,
      role: message.role,
      content: message.content,
      sources: message.sources,
      createdAt: new Date(),
    };

    if (!this.chatMessages.has(message.sessionId)) {
      this.chatMessages.set(message.sessionId, []);
    }
    this.chatMessages.get(message.sessionId)!.push(chatMessage);
    
    return chatMessage;
  }

  async getDocumentChunks(): Promise<DocumentChunk[]> {
    return this.documentChunks;
  }

  async addDocumentChunk(chunk: any): Promise<DocumentChunk> {
    const id = this.currentChunkId++;
    const documentChunk: DocumentChunk = {
      id,
      content: chunk.content,
      metadata: chunk.metadata,
      createdAt: new Date(),
    };
    
    this.documentChunks.push(documentChunk);
    return documentChunk;
  }
}

export const storage = new MemStorage();
